function myfunc3() {
  var x = document.getElementById("quantity1").value * 150.95;
  var y = document.getElementById("quantity2").value * 180.95;
  document.getElementById("total1").innerHTML = x.toFixed(2);
  document.getElementById("total2").innerHTML = y.toFixed(2);
  document.getElementById("total3").innerHTML = (x + y).toFixed(2);
}
